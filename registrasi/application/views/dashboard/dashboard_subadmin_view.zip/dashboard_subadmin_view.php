<!-- START BREADCRUMB -->
<ul class="breadcrumb">
    <li><a href="#">Home</a></li>
    <li class="active">Dashboard Sub-Admin</li>
</ul>
<!-- END BREADCRUMB -->

<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">

    <!-- START WIDGETS -->
    <div class="row">
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsypaper') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_jenis', 'Psy-Paper');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Paper</div>
                    <div class="widget-subtitle">Registered</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyintervention') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                   $this->db->where('reg_jenis', 'Psy-Intervention');
                   $this->db->where('reg_universitas', $nama);
                   $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Intervention</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyproposal') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                   $this->db->where('reg_jenis', 'Psy-Proposal');
                   $this->db->where('reg_universitas', $nama);
                   $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Proposal</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        <div class="col-md-3">

            <!-- START WIDGET CLOCK -->
            <div class="widget widget-danger widget-padding-sm">
                <div class="widget-big-int plugin-clock">00:00</div>
                <div class="widget-subtitle plugin-date">Loading...</div>
                <div class="widget-controls">
                </div>
                <div class="widget-buttons widget-c3">
                    <div class="col">
                        <a href="#"><span class="fa fa-clock-o"></span></a>
                    </div>
                    <div class="col">
                        <a href="#"><span class="fa fa-bell"></span></a>
                    </div>
                    <div class="col">
                        <a href="#"><span class="fa fa-calendar"></span></a>
                    </div>
                </div>
            </div>
            <!-- END WIDGET CLOCK -->

        </div>
    </div>
    <!-- END WIDGETS -->

    <!-- START WIDGETS -->
    <div class="row">
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsydesign') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                   $this->db->where('reg_jenis', 'Psy-Design');
                   $this->db->where('reg_universitas', $nama);
                   $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Design</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyinfografis') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_jenis', 'Psy-Infografis');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Infografis</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyessay') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_jenis', 'Psy-Essay');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Essay</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsymovie') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_jenis', 'Psy-Film');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Film</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>

    </div>
    <!-- END WIDGETS -->
    
       <!-- START WIDGETS -->
    <div class="row">
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyvlog') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_jenis', 'Psy-Vlog');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Vlog</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyphotography') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_jenis', 'Psy-Photography');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Psy-Photography</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->

        </div>
        
        <div class="col-md-3">

<!-- START WIDGET REGISTRED -->
<div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsypreach') ?>';">
    <div class="widget-item-left">
        <span class="fa fa-user"></span>
    </div>
    <div class="widget-data">
    <?php    
    $nama = $this->session->userdata('nama');
    ?>
        <?php $this->db->select('*');
        $this->db->where('reg_jenis', 'Psy-Preach');
        $this->db->where('reg_universitas', $nama);
        $query = $this->db->get('tbl_reg');
        ?>
        <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
        <div class="widget-title">Psy-Preach</div>
        <div class="widget-subtitle">Registrasi</div>
    </div>
    <div class="widget-controls">
    </div>
</div>
<!-- END WIDGET REGISTRED -->

</div>

<div class="col-md-3">

<!-- START WIDGET REGISTRED -->
<div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPsyqiraah') ?>';">
    <div class="widget-item-left">
        <span class="fa fa-user"></span>
    </div>
    <div class="widget-data">
    <?php    
    $nama = $this->session->userdata('nama');
    ?>
        <?php $this->db->select('*');
        $this->db->where('reg_jenis', 'Psy-Qiraah');
        $this->db->where('reg_universitas', $nama);
        $query = $this->db->get('tbl_reg');
        ?>
        <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
        <div class="widget-title">Psy-Qiraah</div>
        <div class="widget-subtitle">Registrasi</div>
    </div>
    <div class="widget-controls">
    </div>
</div>
<!-- END WIDGET REGISTRED -->

</div>

    </div>
    <!-- END WIDGETS -->
    
       <!-- START WIDGETS -->
    <div class="row">

        
        <div class="col-md-3">

            <!-- START WIDGET REGISTRED -->
            <div class="widget widget-default widget-item-icon" onclick="location.href='<?= base_url('SubPeserta') ?>';">
                <div class="widget-item-left">
                    <span class="fa fa-user"></span>
                </div>
                <div class="widget-data">
                <?php    
                $nama = $this->session->userdata('nama');
                ?>
                    <?php $this->db->select('*');
                    $this->db->where('reg_universitas', $nama);
                    $query = $this->db->get('tbl_reg');
                    ?>
                    <div class="widget-int num-count"><?php echo $query->num_rows(); ?></div>
                    <div class="widget-title">Peserta</div>
                    <div class="widget-subtitle">Registrasi</div>
                </div>
                <div class="widget-controls">
                </div>
            </div>
            <!-- END WIDGET REGISTRED -->
            

        </div>
</div>    
  
    <!-- END WIDGETS -->